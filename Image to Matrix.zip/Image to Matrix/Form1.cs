﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.IO;
using System.Runtime.InteropServices;

namespace Image_to_Matrix
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            string chars = "0123456789";
            Font font = new Font("Consolas", 10f, FontStyle.Regular);

            RichTextBox rtb = new RichTextBox
            {
                Parent = this,
                Size = new Size(ClientSize.Width - 90, ClientSize.Height - 10),
                Location = new Point(85, 5),
                Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right,
                Font = font,
                WordWrap = false,
                Visible = false,
                BackColor = Color.Black,
                ForeColor = Color.White,
            };
            Button b1 = new Button
            {
                Parent = this,
                Size = new Size(75, 20),
                Location = new Point(5, 5),
                Text = "Open",
            };
            Button b2 = new Button
            {
                Parent = this,
                Size = new Size(75, 20),
                Location = new Point(5, 30),
                Text = "Matricise",
            };
            PictureBox pb1 = new PictureBox
            {
                Parent = this,
                Size = new Size(ClientSize.Width - 90, ClientSize.Height - 10),
                Location = new Point(85, 5),
                SizeMode = PictureBoxSizeMode.Zoom,
            };
            Bitmap pb1img = null;
            NumericUpDown nud1 = new NumericUpDown
            {
                Parent = this,
                Size = new Size(35, 20),
                Location = new Point(5, 55),
                Value = 100,
                Maximum = 10000,
            };
            NumericUpDown nud2 = new NumericUpDown
            {
                Parent = this,
                Size = new Size(35, 20),
                Location = new Point(45, 55),
                Value = 100,
                Maximum = 10000,
            };
            Button b3 = new Button
            {
                Parent = this,
                Size = new Size(75, 20),
                Location = new Point(5, 80),
                Text = "Save",
            };

            // setup

            Dictionary<char, double> index = new Dictionary<char, double>();
            Bitmap bmp = new Bitmap(Convert.ToInt32(font.Size * 1.5f), Convert.ToInt32(font.Size * 1.5f));
            using (SolidBrush sb = new SolidBrush(Color.Black))
            using (Graphics g = Graphics.FromImage(bmp))
                foreach (char c in chars)
                {
                    g.Clear(Color.White);
                    g.DrawString(c.ToString(), font, sb, 0, 0);
                    BitmapData data = bmp.LockBits(new Rectangle(0, 0, bmp.Width, bmp.Height), ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);
                    byte[] rgba = new byte[data.Stride * data.Height];
                    Marshal.Copy(data.Scan0, rgba, 0, data.Stride * data.Height);
                    bmp.UnlockBits(data);
                    index.Add(c, rgba.Average(x => x));
                    Array.Clear(rgba, 0, rgba.Length);
                }
            List<char> ordered = index.OrderBy(x => x.Value).Select(x => x.Key).ToList();
            double min = index.Min(x => x.Value);
            double max = index.Max(x => x.Value);
            Dictionary<byte, char> lookup = new Dictionary<byte, char>();
            for (byte i = 0; i < 255; i++)
                lookup.Add(i, ordered[(int)Math.Floor(i * chars.Length / 255d)]);
            for (byte i = 0; i < 255; i++)
                if (!lookup.ContainsKey(i))
                    lookup.Add(i, ' ');

            b1.MouseClick += (sender, e) =>
            {
                OpenFileDialog ofd = new OpenFileDialog();
                if (ofd.ShowDialog() == DialogResult.OK)
                    try
                    {
                        pb1img = (Bitmap)Image.FromFile(ofd.FileName);
                        pb1.Image = pb1img;
                    }
                    catch
                    {
                        rtb.Text = File.ReadAllText(ofd.FileName);
                        rtb.Visible = true;
                    }
            };
            b2.MouseClick += (sender, e) =>
            {
                Bitmap pb1img2 = new Bitmap((int)nud1.Value, (int)nud2.Value);
                using (Graphics g = Graphics.FromImage(pb1img2))
                {
                    g.CompositingQuality = System.Drawing.Drawing2D.CompositingQuality.HighQuality;
                    ImageAttributes ia = new ImageAttributes();
                    ia.SetColorMatrix(new ColorMatrix(new float[][] {
                        new float[] {.3f, .3f, .3f, 0, 0},
                        new float[] {.59f, .59f, .59f, 0, 0},
                        new float[] {.11f, .11f, .11f, 0, 0},
                        new float[] {0, 0, 0, 1, 0},
                        new float[] {0, 0, 0, 0, 1}
                    }));
                    g.DrawImage(pb1img, new Rectangle(new Point(), pb1img2.Size), 0, 0, pb1img.Width, pb1img.Height, GraphicsUnit.Pixel, ia);
                }
                BitmapData data = pb1img2.LockBits(new Rectangle(new Point(), pb1img2.Size), ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);
                byte[] rgba = new byte[data.Stride * data.Height];
                Marshal.Copy(data.Scan0, rgba, 0, data.Stride * data.Height);
                pb1img2.UnlockBits(data);
                IEnumerable<char> colours = Enumerable.Range(0, rgba.Length / 4).Select(x => lookup.ContainsKey(rgba[x * 4]) ? lookup[rgba[x * 4]] : ' ');
                rtb.Text = "[" + string.Join("\n ", Enumerable.Range(0, pb1img2.Height).Select(x => string.Join(",", colours.Skip(x * pb1img2.Width).Take(pb1img2.Width)))) + "]";
                rtb.Visible = true;
                using (Graphics g = CreateGraphics())
                    Text = g.MeasureString(rtb.Text, rtb.Font).ToString();
            };
            b3.MouseClick += (sender, e) =>
            {
                SaveFileDialog sfd = new SaveFileDialog
                {
                    Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*",
                };
                if (sfd.ShowDialog() == DialogResult.OK)
                    if (!File.Exists(sfd.FileName))
                        File.WriteAllText(sfd.FileName, rtb.Text);
                    else
                        MessageBox.Show("That file already exists!", "Error");
            };
        }
    }
}
